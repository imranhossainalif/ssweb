const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('#main-nav');
function closeMenu() { toggle.setAttribute('aria-expanded', 'false'); nav.classList.remove('open'); }
toggle.addEventListener('click', () => { const open = toggle.getAttribute('aria-expanded') !== 'true'; toggle.setAttribute('aria-expanded', String(open)); nav.classList.toggle('open', open); });
document.addEventListener('keydown', event => { if (event.key === 'Escape') { const active = document.activeElement; document.querySelectorAll('nav details[open]').forEach(el => { el.open = false; if (el.contains(active)) el.querySelector('summary').focus(); }); if (nav.classList.contains('open')) { closeMenu(); toggle.focus(); } } });
document.addEventListener('click', event => { document.querySelectorAll('nav details[open]').forEach(el => { if (!el.contains(event.target)) el.open = false; }); });

// Reflect the current page without changing the familiar navigation labels.
const currentPath = window.location.pathname;
document.querySelectorAll('#main-nav a').forEach(link => {
  if (new URL(link.href).pathname === currentPath) link.setAttribute('aria-current', 'page');
});
const menuWidth = window.matchMedia('(min-width: 821px)');
menuWidth.addEventListener('change', () => { if (menuWidth.matches) closeMenu(); });
document.querySelectorAll('form').forEach(form => {
  const submit = form.querySelector('[data-submit]');
  const status = form.querySelector('.submit-status');
  if (!submit) return;
  form.addEventListener('submit', () => {
    if (!form.checkValidity()) return;
    submit.disabled = true;
    form.setAttribute('aria-busy', 'true');
    if (status) status.textContent = 'Sending your request…';
  });
  window.addEventListener('pageshow', () => {
    submit.disabled = false;
    form.removeAttribute('aria-busy');
    if (status) status.textContent = '';
  });
});
const errorSummary = document.querySelector('.error[role="alert"]');
if (errorSummary) errorSummary.focus();
